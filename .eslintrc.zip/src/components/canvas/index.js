import EarthCanvas from "./Earth";
import StarsCanvas from "./Stars";

export { EarthCanvas, StarsCanvas };
